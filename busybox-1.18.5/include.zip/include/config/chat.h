#define CONFIG_CHAT 1
