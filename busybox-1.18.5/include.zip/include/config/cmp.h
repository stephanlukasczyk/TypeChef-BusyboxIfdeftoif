#define CONFIG_CMP 1
