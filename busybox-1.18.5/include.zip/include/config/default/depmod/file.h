#define CONFIG_DEFAULT_DEPMOD_FILE "modules.dep"
