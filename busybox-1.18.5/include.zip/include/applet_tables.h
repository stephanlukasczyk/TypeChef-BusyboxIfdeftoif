/* This is a generated file, don't edit */

#define NUM_APPLETS 335

const char applet_names[] ALIGN1 = ""
"[" "\0"
"[[" "\0"
"acpid" "\0"
"add-shell" "\0"
"addgroup" "\0"
"adduser" "\0"
"adjtimex" "\0"
"arp" "\0"
"arping" "\0"
"ash" "\0"
"awk" "\0"
"base64" "\0"
"basename" "\0"
"beep" "\0"
"blkid" "\0"
"blockdev" "\0"
"bootchartd" "\0"
"brctl" "\0"
"bunzip2" "\0"
"bzcat" "\0"
"bzip2" "\0"
"cal" "\0"
"cat" "\0"
"catv" "\0"
"chat" "\0"
"chattr" "\0"
"chgrp" "\0"
"chmod" "\0"
"chown" "\0"
"chpasswd" "\0"
"chpst" "\0"
"chroot" "\0"
"chrt" "\0"
"chvt" "\0"
"cksum" "\0"
"clear" "\0"
"cmp" "\0"
"comm" "\0"
"cp" "\0"
"cpio" "\0"
"crond" "\0"
"crontab" "\0"
"cryptpw" "\0"
"cttyhack" "\0"
"cut" "\0"
"date" "\0"
"dc" "\0"
"dd" "\0"
"deallocvt" "\0"
"delgroup" "\0"
"deluser" "\0"
"depmod" "\0"
"devmem" "\0"
"df" "\0"
"dhcprelay" "\0"
"diff" "\0"
"dirname" "\0"
"dmesg" "\0"
"dnsd" "\0"
"dnsdomainname" "\0"
"dos2unix" "\0"
"du" "\0"
"dumpkmap" "\0"
"dumpleases" "\0"
"echo" "\0"
"ed" "\0"
"egrep" "\0"
"eject" "\0"
"env" "\0"
"envdir" "\0"
"envuidgid" "\0"
"ether-wake" "\0"
"expand" "\0"
"expr" "\0"
"fakeidentd" "\0"
"false" "\0"
"fbset" "\0"
"fbsplash" "\0"
"fdflush" "\0"
"fdformat" "\0"
"fdisk" "\0"
"fgconsole" "\0"
"fgrep" "\0"
"find" "\0"
"findfs" "\0"
"flock" "\0"
"fold" "\0"
"free" "\0"
"freeramdisk" "\0"
"fsck" "\0"
"fsck.minix" "\0"
"fsync" "\0"
"ftpd" "\0"
"ftpget" "\0"
"ftpput" "\0"
"fuser" "\0"
"getopt" "\0"
"getty" "\0"
"grep" "\0"
"gunzip" "\0"
"gzip" "\0"
"halt" "\0"
"hd" "\0"
"hdparm" "\0"
"head" "\0"
"hexdump" "\0"
"hostid" "\0"
"hostname" "\0"
"httpd" "\0"
"hush" "\0"
"hwclock" "\0"
"id" "\0"
"ifconfig" "\0"
"ifdown" "\0"
"ifenslave" "\0"
"ifplugd" "\0"
"ifup" "\0"
"inetd" "\0"
"init" "\0"
"insmod" "\0"
"install" "\0"
"ionice" "\0"
"iostat" "\0"
"ip" "\0"
"ipaddr" "\0"
"ipcalc" "\0"
"ipcrm" "\0"
"ipcs" "\0"
"iplink" "\0"
"iproute" "\0"
"iprule" "\0"
"iptunnel" "\0"
"kbd_mode" "\0"
"kill" "\0"
"killall" "\0"
"killall5" "\0"
"klogd" "\0"
"last" "\0"
"length" "\0"
"less" "\0"
"linux32" "\0"
"linux64" "\0"
"linuxrc" "\0"
"ln" "\0"
"loadfont" "\0"
"loadkmap" "\0"
"logger" "\0"
"login" "\0"
"logname" "\0"
"logread" "\0"
"losetup" "\0"
"lpd" "\0"
"lpq" "\0"
"lpr" "\0"
"ls" "\0"
"lsattr" "\0"
"lsmod" "\0"
"lspci" "\0"
"lsusb" "\0"
"lzcat" "\0"
"lzma" "\0"
"lzop" "\0"
"lzopcat" "\0"
"makedevs" "\0"
"makemime" "\0"
"man" "\0"
"md5sum" "\0"
"mdev" "\0"
"mesg" "\0"
"microcom" "\0"
"mkdir" "\0"
"mkdosfs" "\0"
"mke2fs" "\0"
"mkfifo" "\0"
"mkfs.ext2" "\0"
"mkfs.minix" "\0"
"mkfs.vfat" "\0"
"mknod" "\0"
"mkpasswd" "\0"
"mkswap" "\0"
"mktemp" "\0"
"modinfo" "\0"
"modprobe" "\0"
"more" "\0"
"mount" "\0"
"mountpoint" "\0"
"mpstat" "\0"
"mt" "\0"
"mv" "\0"
"nameif" "\0"
"nbd-client" "\0"
"nc" "\0"
"netstat" "\0"
"nice" "\0"
"nmeter" "\0"
"nohup" "\0"
"nslookup" "\0"
"ntpd" "\0"
"od" "\0"
"openvt" "\0"
"passwd" "\0"
"patch" "\0"
"pgrep" "\0"
"pidof" "\0"
"ping" "\0"
"ping6" "\0"
"pipe_progress" "\0"
"pivot_root" "\0"
"pkill" "\0"
"pmap" "\0"
"popmaildir" "\0"
"poweroff" "\0"
"powertop" "\0"
"printenv" "\0"
"printf" "\0"
"ps" "\0"
"pscan" "\0"
"pwd" "\0"
"raidautorun" "\0"
"rdate" "\0"
"rdev" "\0"
"readahead" "\0"
"readlink" "\0"
"readprofile" "\0"
"realpath" "\0"
"reboot" "\0"
"reformime" "\0"
"remove-shell" "\0"
"renice" "\0"
"reset" "\0"
"resize" "\0"
"rev" "\0"
"rm" "\0"
"rmdir" "\0"
"rmmod" "\0"
"route" "\0"
"rpm" "\0"
"rpm2cpio" "\0"
"rtcwake" "\0"
"run-parts" "\0"
"runlevel" "\0"
"runsv" "\0"
"runsvdir" "\0"
"rx" "\0"
"script" "\0"
"scriptreplay" "\0"
"sed" "\0"
"sendmail" "\0"
"seq" "\0"
"setarch" "\0"
"setconsole" "\0"
"setfont" "\0"
"setkeycodes" "\0"
"setlogcons" "\0"
"setsid" "\0"
"setuidgid" "\0"
"sh" "\0"
"sha1sum" "\0"
"sha256sum" "\0"
"sha512sum" "\0"
"showkey" "\0"
"slattach" "\0"
"sleep" "\0"
"smemcap" "\0"
"softlimit" "\0"
"sort" "\0"
"split" "\0"
"start-stop-daemon" "\0"
"stat" "\0"
"strings" "\0"
"stty" "\0"
"su" "\0"
"sulogin" "\0"
"sum" "\0"
"sv" "\0"
"svlogd" "\0"
"swapoff" "\0"
"swapon" "\0"
"switch_root" "\0"
"sync" "\0"
"sysctl" "\0"
"syslogd" "\0"
"tac" "\0"
"tail" "\0"
"tar" "\0"
"tee" "\0"
"telnet" "\0"
"telnetd" "\0"
"test" "\0"
"tftp" "\0"
"tftpd" "\0"
"time" "\0"
"timeout" "\0"
"top" "\0"
"touch" "\0"
"tr" "\0"
"traceroute" "\0"
"traceroute6" "\0"
"true" "\0"
"tty" "\0"
"ttysize" "\0"
"tunctl" "\0"
"udhcpc" "\0"
"udhcpd" "\0"
"umount" "\0"
"uname" "\0"
"unexpand" "\0"
"uniq" "\0"
"unix2dos" "\0"
"unlzma" "\0"
"unlzop" "\0"
"unxz" "\0"
"unzip" "\0"
"uptime" "\0"
"usleep" "\0"
"uudecode" "\0"
"uuencode" "\0"
"vconfig" "\0"
"vi" "\0"
"vlock" "\0"
"volname" "\0"
"wall" "\0"
"watch" "\0"
"watchdog" "\0"
"wc" "\0"
"wget" "\0"
"which" "\0"
"who" "\0"
"whoami" "\0"
"xargs" "\0"
"xz" "\0"
"xzcat" "\0"
"yes" "\0"
"zcat" "\0"
"zcip" "\0"
;

#ifndef SKIP_applet_main
int (*const applet_main[])(int argc, char **argv) = {
test_main,
test_main,
acpid_main,
add_remove_shell_main,
addgroup_main,
adduser_main,
adjtimex_main,
arp_main,
arping_main,
ash_main,
awk_main,
base64_main,
basename_main,
beep_main,
blkid_main,
blockdev_main,
bootchartd_main,
brctl_main,
bunzip2_main,
bunzip2_main,
bzip2_main,
cal_main,
cat_main,
catv_main,
chat_main,
chattr_main,
chgrp_main,
chmod_main,
chown_main,
chpasswd_main,
chpst_main,
chroot_main,
chrt_main,
chvt_main,
cksum_main,
clear_main,
cmp_main,
comm_main,
cp_main,
cpio_main,
crond_main,
crontab_main,
cryptpw_main,
cttyhack_main,
cut_main,
date_main,
dc_main,
dd_main,
deallocvt_main,
deluser_main,
deluser_main,
modprobe_main,
devmem_main,
df_main,
dhcprelay_main,
diff_main,
dirname_main,
dmesg_main,
dnsd_main,
hostname_main,
dos2unix_main,
du_main,
dumpkmap_main,
dumpleases_main,
echo_main,
ed_main,
grep_main,
eject_main,
env_main,
chpst_main,
chpst_main,
ether_wake_main,
expand_main,
expr_main,
fakeidentd_main,
false_main,
fbset_main,
fbsplash_main,
freeramdisk_main,
fdformat_main,
fdisk_main,
fgconsole_main,
grep_main,
find_main,
findfs_main,
flock_main,
fold_main,
free_main,
freeramdisk_main,
fsck_main,
fsck_minix_main,
fsync_main,
ftpd_main,
ftpgetput_main,
ftpgetput_main,
fuser_main,
getopt_main,
getty_main,
grep_main,
gunzip_main,
gzip_main,
halt_main,
hexdump_main,
hdparm_main,
head_main,
hexdump_main,
hostid_main,
hostname_main,
httpd_main,
hush_main,
hwclock_main,
id_main,
ifconfig_main,
ifupdown_main,
ifenslave_main,
ifplugd_main,
ifupdown_main,
inetd_main,
init_main,
modprobe_main,
install_main,
ionice_main,
iostat_main,
ip_main,
ipaddr_main,
ipcalc_main,
ipcrm_main,
ipcs_main,
iplink_main,
iproute_main,
iprule_main,
iptunnel_main,
kbd_mode_main,
kill_main,
kill_main,
kill_main,
klogd_main,
last_main,
length_main,
less_main,
setarch_main,
setarch_main,
init_main,
ln_main,
loadfont_main,
loadkmap_main,
logger_main,
login_main,
logname_main,
logread_main,
losetup_main,
lpd_main,
lpqr_main,
lpqr_main,
ls_main,
lsattr_main,
modprobe_main,
lspci_main,
lsusb_main,
unlzma_main,
unlzma_main,
lzop_main,
lzop_main,
makedevs_main,
makemime_main,
man_main,
md5_sha1_sum_main,
mdev_main,
mesg_main,
microcom_main,
mkdir_main,
mkfs_vfat_main,
mkfs_ext2_main,
mkfifo_main,
mkfs_ext2_main,
mkfs_minix_main,
mkfs_vfat_main,
mknod_main,
cryptpw_main,
mkswap_main,
mktemp_main,
modinfo_main,
modprobe_main,
more_main,
mount_main,
mountpoint_main,
mpstat_main,
mt_main,
mv_main,
nameif_main,
nbdclient_main,
nc_main,
netstat_main,
nice_main,
nmeter_main,
nohup_main,
nslookup_main,
ntpd_main,
od_main,
openvt_main,
passwd_main,
patch_main,
pgrep_main,
pidof_main,
ping_main,
ping6_main,
pipe_progress_main,
pivot_root_main,
pgrep_main,
pmap_main,
popmaildir_main,
halt_main,
powertop_main,
printenv_main,
printf_main,
ps_main,
pscan_main,
pwd_main,
raidautorun_main,
rdate_main,
rdev_main,
readahead_main,
readlink_main,
readprofile_main,
realpath_main,
halt_main,
reformime_main,
add_remove_shell_main,
renice_main,
reset_main,
resize_main,
rev_main,
rm_main,
rmdir_main,
modprobe_main,
route_main,
rpm_main,
rpm2cpio_main,
rtcwake_main,
run_parts_main,
runlevel_main,
runsv_main,
runsvdir_main,
rx_main,
script_main,
scriptreplay_main,
sed_main,
sendmail_main,
seq_main,
setarch_main,
setconsole_main,
setfont_main,
setkeycodes_main,
setlogcons_main,
setsid_main,
chpst_main,
ash_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
showkey_main,
slattach_main,
sleep_main,
smemcap_main,
chpst_main,
sort_main,
split_main,
start_stop_daemon_main,
stat_main,
strings_main,
stty_main,
su_main,
sulogin_main,
sum_main,
sv_main,
svlogd_main,
swap_on_off_main,
swap_on_off_main,
switch_root_main,
sync_main,
sysctl_main,
syslogd_main,
tac_main,
tail_main,
tar_main,
tee_main,
telnet_main,
telnetd_main,
test_main,
tftp_main,
tftpd_main,
time_main,
timeout_main,
top_main,
touch_main,
tr_main,
traceroute_main,
traceroute6_main,
true_main,
tty_main,
ttysize_main,
tunctl_main,
udhcpc_main,
udhcpd_main,
umount_main,
uname_main,
expand_main,
uniq_main,
dos2unix_main,
unlzma_main,
lzop_main,
unxz_main,
unzip_main,
uptime_main,
usleep_main,
uudecode_main,
uuencode_main,
vconfig_main,
vi_main,
vlock_main,
volname_main,
wall_main,
watch_main,
watchdog_main,
wc_main,
wget_main,
which_main,
who_main,
whoami_main,
xargs_main,
unxz_main,
unxz_main,
yes_main,
gunzip_main,
zcip_main,
};
#endif

const uint16_t applet_nameofs[] ALIGN2 = {
0x0000,
0x0002,
0x0005,
0x000b,
0x0015,
0x001e,
0x0026,
0x002f,
0x0033,
0x003a,
0x003e,
0x0042,
0x0049,
0x0052,
0x0057,
0x005d,
0x0066,
0x0071,
0x0077,
0x007f,
0x0085,
0x008b,
0x008f,
0x0093,
0x0098,
0x009d,
0x00a4,
0x00aa,
0x00b0,
0x00b6,
0x00bf,
0x00c5,
0x00cc,
0x00d1,
0x00d6,
0x00dc,
0x00e2,
0x00e6,
0x00eb,
0x00ee,
0x00f3,
0x80f9,
0x0101,
0x0109,
0x0112,
0x0116,
0x011b,
0x011e,
0x0121,
0x012b,
0x0134,
0x013c,
0x0143,
0x014a,
0x014d,
0x0157,
0x015c,
0x0164,
0x816a,
0x016f,
0x017d,
0x0186,
0x0189,
0x0192,
0x019d,
0x01a2,
0x01a5,
0x01ab,
0x01b1,
0x01b5,
0x01bc,
0x01c6,
0x01d1,
0x01d8,
0x01dd,
0x01e8,
0x01ee,
0x01f4,
0x01fd,
0x0205,
0x020e,
0x0214,
0x021e,
0x0224,
0x4229,
0x0230,
0x0236,
0x023b,
0x0240,
0x024c,
0x0251,
0x025c,
0x0262,
0x0267,
0x026e,
0x0275,
0x027b,
0x0282,
0x0288,
0x028d,
0x0294,
0x0299,
0x029e,
0x02a1,
0x02a8,
0x02ad,
0x02b5,
0x02bc,
0x02c5,
0x02cb,
0x02d0,
0x02d8,
0x02db,
0x02e4,
0x02eb,
0x02f5,
0x02fd,
0x0302,
0x0308,
0x030d,
0x0314,
0x031c,
0x0323,
0x032a,
0x032d,
0x0334,
0x833b,
0x8341,
0x0346,
0x034d,
0x0355,
0x035c,
0x0365,
0x036e,
0x0373,
0x037b,
0x0384,
0x038a,
0x038f,
0x0396,
0x039b,
0x03a3,
0x03ab,
0x03b3,
0x03b6,
0x03bf,
0x03c8,
0x83cf,
0x03d5,
0x03dd,
0x03e5,
0x03ed,
0x03f1,
0x03f5,
0x03f9,
0x03fc,
0x0403,
0x0409,
0x040f,
0x0415,
0x041b,
0x0420,
0x0425,
0x042d,
0x0436,
0x043f,
0x0443,
0x044a,
0x044f,
0x0454,
0x045d,
0x0463,
0x046b,
0x0472,
0x0479,
0x0483,
0x048e,
0x0498,
0x049e,
0x04a7,
0x04ae,
0x04b5,
0x04bd,
0x04c6,
0x44cb,
0x04d1,
0x04dc,
0x04e3,
0x04e6,
0x04e9,
0x04f0,
0x04fb,
0x04fe,
0x0506,
0x050b,
0x0512,
0x0518,
0x0521,
0x0526,
0x0529,
0x8530,
0x0537,
0x053d,
0x0543,
0x4549,
0x454e,
0x0554,
0x0562,
0x056d,
0x0573,
0x0578,
0x0583,
0x058c,
0x0595,
0x059e,
0x05a5,
0x05a8,
0x05ae,
0x05b2,
0x05be,
0x05c4,
0x05c9,
0x05d3,
0x05dc,
0x05e8,
0x05f1,
0x05f8,
0x0602,
0x060f,
0x0616,
0x061c,
0x0623,
0x0627,
0x062a,
0x0630,
0x0636,
0x063c,
0x0640,
0x0649,
0x0651,
0x065b,
0x0664,
0x066a,
0x0673,
0x0676,
0x067d,
0x068a,
0x068e,
0x0697,
0x069b,
0x06a3,
0x06ae,
0x06b6,
0x06c2,
0x06cd,
0x06d4,
0x06de,
0x06e1,
0x06e9,
0x06f3,
0x06fd,
0x0705,
0x070e,
0x0714,
0x071c,
0x0726,
0x072b,
0x0731,
0x0743,
0x0748,
0x0750,
0x8755,
0x0758,
0x0760,
0x0764,
0x0767,
0x076e,
0x0776,
0x077d,
0x0789,
0x078e,
0x0795,
0x079d,
0x07a1,
0x07a6,
0x07aa,
0x07ae,
0x07b5,
0x07bd,
0x07c2,
0x07c7,
0x07cd,
0x07d2,
0x07da,
0x07de,
0x07e4,
0x47e7,
0x47f2,
0x07fe,
0x0803,
0x0807,
0x080f,
0x0816,
0x081d,
0x0824,
0x082b,
0x0831,
0x083a,
0x083f,
0x0848,
0x084f,
0x0856,
0x085b,
0x0861,
0x0868,
0x086f,
0x0878,
0x0881,
0x0889,
0x888c,
0x0892,
0x889a,
0x089f,
0x08a5,
0x08ae,
0x08b1,
0x08b6,
0x08bc,
0x08c0,
0x08c7,
0x08cd,
0x08d0,
0x08d6,
0x08da,
0x08df,
};

const uint8_t applet_install_loc[] ALIGN1 = {
0x33,
0x32,
0x11,
0x22,
0x13,
0x13,
0x33,
0x22,
0x42,
0x33,
0x33,
0x11,
0x13,
0x11,
0x41,
0x43,
0x33,
0x33,
0x33,
0x11,
0x34,
0x13,
0x13,
0x13,
0x13,
0x21,
0x12,
0x34,
0x13,
0x14,
0x33,
0x31,
0x11,
0x31,
0x33,
0x33,
0x33,
0x14,
0x24,
0x31,
0x32,
0x31,
0x32,
0x33,
0x22,
0x12,
0x34,
0x33,
0x21,
0x11,
0x21,
0x23,
0x33,
0x13,
0x14,
0x32,
0x22,
0x32,
0x42,
0x22,
0x13,
0x11,
0x11,
0x33,
0x11,
0x11,
0x13,
0x33,
0x32,
0x33,
0x11,
0x10,
0x24,
0x13,
0x23,
0x42,
0x33,
0x11,
0x32,
0x33,
0x13,
0x23,
0x21,
0x23,
0x33,
0x21,
0x32,
0x22,
0x12,
0x23,
0x21,
0x12,
0x11,
0x11,
0x21,
0x34,
0x11,
0x33,
0x43,
0x33,
0x33,
0x13,
0x11,
0x21,
0x33,
0x24,
0x11,
0x13,
0x13,
0x42,
0x34,
0x43,
0x23,
0x31,
0x33,
0x13,
0x11,
0x22,
0x31,
0x13,
0x32,
0x33,
0x13,
0x41,
0x13,
0x42,
0x43,
0x33,
0x31,
0x33,
0x23,
0x31,
0x33,
0x23,
0x31,
0x11,
0x32,
0x43,
0x22,
0x12,
0x22,
0x33,
0x31,
0x43,
0x33,
0x33,
0x33,
0x31,
0x33,
0x31,
0x23,
0x42,
0x11,
0x33,
0x33,
0x33,
0x33,
0x31,
0x23,
0x31,
0x33,
0x21,
0x33,
0x33,
0x33,
0x33,
0x13,
0x02,
};

#define MAX_APPLET_NAME_LEN 17
